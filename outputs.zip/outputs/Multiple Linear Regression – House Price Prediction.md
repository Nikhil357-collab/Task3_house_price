# Multiple Linear Regression – House Price Prediction

## Project Overview

This project implements a **Multiple Linear Regression** model to predict house prices using property-related features such as area, bedrooms, bathrooms, stories, parking, location-related attributes, and other facilities.

The project demonstrates the complete machine learning workflow:

**Data Loading → Preprocessing → Train/Test Split → Model Training → Prediction → Evaluation → Residual Analysis → Interpretation**

---

## Objective

The main objectives of this project are:

- Import and preprocess the housing dataset.
- Separate independent and dependent variables.
- Encode categorical features.
- Split the dataset into training and testing sets.
- Train a Multiple Linear Regression model using `sklearn`.
- Predict house prices on unseen test data.
- Evaluate the model using MAE, MSE, RMSE and R².
- Analyze regression coefficients.
- Perform residual analysis.
- Visualize actual versus predicted prices.

---

## Dataset

The project uses `Housing.csv`.

### Target Variable

```text
price
```

### Features

The dataset contains features such as:

- `area`
- `bedrooms`
- `bathrooms`
- `stories`
- `parking`
- `mainroad`
- `guestroom`
- `basement`
- `hotwaterheating`
- `airconditioning`
- `prefarea`
- `furnishingstatus`

Categorical features are converted into numerical dummy variables before model training.

---

## Project Structure

```text
AIML_T2MODEL/
│
├── data/
│   └── Housing.csv
│
├── src/
│   ├── data_preprocessing.py
│   ├── train_model.py
│   ├── evaluate_model.py
│   ├── diagnostics.py
│   └── main.py
│
├── README.md
└── requirements.txt
```

---

## Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Statsmodels

---

## Machine Learning Model

The project uses:

```python
from sklearn.linear_model import LinearRegression
```

Multiple Linear Regression models the relationship between the target and multiple predictors:

```text
Price =
Intercept
+ β1(Area)
+ β2(Bedrooms)
+ β3(Bathrooms)
+ ...
```

---

## What is a Coefficient?

A coefficient represents the estimated change in the predicted target for a one-unit increase in a feature, while keeping the other predictors constant.

For example, if:

```text
bedrooms = 76,778.70
```

the interpretation is:

> According to the fitted model, one additional bedroom is associated with an estimated increase of approximately 76,779 in house price, holding the other included predictors constant.

Coefficients make Linear Regression interpretable because they allow us to understand the estimated relationship between individual features and the target.

---

## Model Evaluation

The model is evaluated using four metrics.

### Mean Absolute Error (MAE)

```text
MAE = average(|Actual - Predicted|)
```

MAE represents the average absolute difference between actual and predicted values.

Lower MAE is better.

### Mean Squared Error (MSE)

```text
MSE = average((Actual - Predicted)²)
```

MSE squares the errors, so larger errors receive a greater penalty.

Lower MSE is better.

### Root Mean Squared Error (RMSE)

```text
RMSE = √MSE
```

RMSE converts the squared-error metric back to the original target units.

Lower RMSE is better.

### R² Score

R² measures the proportion of variation in the target that is explained by the model.

Higher R² is generally better, although it should always be evaluated together with other metrics and validation results.

---

## Example of Error Calculation

Suppose:

```text
Actual Price    = ₹500,000
Predicted Price = ₹450,000
```

Then:

```text
Error = 500,000 - 450,000
      = ₹50,000
```

Absolute error:

```text
|50,000| = ₹50,000
```

Squared error:

```text
50,000² = 2,500,000,000
```

The same process is performed across all test observations and then averaged to calculate MAE and MSE.

---

## Model Results

Current test-set results:

```text
Multiple Linear Regression
--------------------------

MAE  : ₹970,043.40
MSE  : ₹1,754,318,687,330.66
RMSE : approximately ₹1,324,507
R²   : 0.6529
```

### Interpretation

The model explains approximately:

```text
65.29%
```

of the variation in house prices on the test set.

The MAE indicates that the average absolute difference between predicted and actual prices is approximately:

```text
₹970,043
```

The RMSE is higher than MAE because RMSE gives greater weight to larger prediction errors.

---

## Simple vs Multiple Linear Regression

A simple Linear Regression model uses one predictor.

Example:

```text
Price = β0 + β1(Area)
```

The simple model achieved:

```text
MAE = ₹1,474,748.13
MSE = ₹3,675,286,604,768.19
R²  = 0.2729
```

The Multiple Linear Regression model achieved:

```text
MAE = ₹970,043.40
MSE = ₹1,754,318,687,330.66
R²  = 0.6529
```

Therefore, Multiple Linear Regression performs substantially better on this test split because it uses multiple property characteristics instead of relying only on area.

---

## Residual Analysis

A residual is calculated as:

```text
Residual = Actual Price - Predicted Price
```

Current residual analysis:

```text
Mean Residual ≈ ₹146,055
Residual Std  ≈ ₹1,322,510
```

The mean residual is relatively close to zero compared with the scale of the target, but the residual standard deviation indicates considerable prediction variability.

Residual plots are used to check whether errors show systematic patterns.

---

## Business Interpretation

The model can be used as a baseline tool for estimating house prices based on available property characteristics.

For example, the fitted model produced positive coefficients for features such as:

- Area
- Bedrooms
- Bathrooms
- Air conditioning
- Preferred area
- Basement

These coefficients represent **model-estimated associations**, not proof of causal effects.

For a business stakeholder, the most important outputs are:

```text
Predicted Price
Expected Error / MAE
Model R²
Important Feature Relationships
```

---

## Limitations

- The dataset is relatively small.
- The model assumes a linear relationship between predictors and target.
- Outliers can influence Linear Regression.
- Multicollinearity may affect coefficient stability.
- R² of 0.6529 does not mean that every prediction is 65.29% accurate.
- The model is evaluated using one train/test split and should be further validated using cross-validation.
- Coefficients should not automatically be interpreted as causal effects.

---

## Future Improvements

The next steps are:

1. Residual diagnostics
2. Multicollinearity analysis using VIF
3. Cross-validation
4. Outlier investigation
5. Feature engineering
6. Standardized coefficient analysis
7. Ridge Regression
8. Lasso Regression
9. Comparison with tree-based models such as Random Forest and XGBoost

---

## How to Run

Navigate to the `src` directory:

```bash
cd AIML_T2MODEL/src
```

Run the complete pipeline:

```bash
python main.py
```

---

## Key Interview Takeaway

> I first developed a Simple Linear Regression baseline using area as the predictor. I then developed a Multiple Linear Regression model using multiple numerical and categorical property features. The multiple model improved the test R² from 0.2729 to 0.6529 and reduced MAE from approximately ₹1.47 million to ₹0.97 million. I also analyzed coefficients and residuals to understand model behavior and identified VIF, cross-validation, and residual diagnostics as the next validation steps.

---

## Author

**Nikhil**

Data Science / Machine Learning Project

**Project:** House Price Prediction using Multiple Linear Regression